const pistol = new Senjata("Pistol", 10);
const rifle = new Senjata("Rifle", 20);
const shotgun = new Senjata("Shotgun", 30);

const player1 = new Player("Player 1", 100);
const player2 = new Player("Player 2", 100);

player1.serang(pistol, player2);

player1.status();
player2.status();
player2.serang(shotgun, player1);
player1.status();