class Senjata {
    // kode yang petama kali dijalankan
    constructor(nama, damage) {
        this.nama = nama;
        this.damage = damage;
    }

    // method
    tembak(player) {
        player.health -= this.damage;

        console.log(`${this.nama} menyerang dengan damage ${this.damage}`);
    }
    reload() {
        console.log(`${this.nama} menyerang dengan damage ${this.damage}`);
    }
    gantiSenjata() {
        console.log(`${this.nama} menyerang dengan damage ${this.damage}`);
    }
}