class Player {
    constructor(nama, health) {
        this.nama = nama;
        this.health = health;
    }

    // method
    serang(senjata, playerLain) {

        senjata.tembak(playerLain);

        console.log(`${this.nama} menyerang dengan ${senjata.nama} dan damage ${senjata.damage}`);
    }

    status() {
        console.log(`${this.nama} memiliki health ${this.health}`);
    }
}